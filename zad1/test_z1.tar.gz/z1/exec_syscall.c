#include <stdio.h>

int main() {
	printf("Main program [syscall]\n");
	return 0;
}
