#include <stdio.h>

int ans = 0;

int main() {
	printf("ans = %d\n", ans);
	return 0;
}
