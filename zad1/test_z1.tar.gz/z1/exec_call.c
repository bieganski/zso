#include <stdio.h>

void some_func() {
	printf("some_func called\n");
}

int main() {
	printf("Main program. [call]\n");
	return 0;
}
